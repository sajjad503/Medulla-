/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "index.html",
    "revision": "c135c24c3c6a41a4e9101c2fa3b89afb"
  }, {
    "url": "assets/index-HkRTN5Qo.js",
    "revision": null
  }, {
    "url": "assets/index-CSV1onOd.css",
    "revision": null
  }, {
    "url": "assets/aistudio/index__1__daf22c29.css",
    "revision": null
  }, {
    "url": "assets/aistudio/api__1__456e304a.js",
    "revision": null
  }, {
    "url": "assets/aistudio/App__1__dfc7b194.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "2c156a49bda10e2cd0ee5e4d1253d880"
  }, {
    "url": "favicon.ico",
    "revision": "7adaf64a29a9be18d204f72f1ea09171"
  }, {
    "url": "icon.svg",
    "revision": "1841a9d886576474e986c63ff42c09c1"
  }, {
    "url": "pwa-192x192.png",
    "revision": "4479171feef0fe5c4d67aad2c60a48f8"
  }, {
    "url": "pwa-512x512.png",
    "revision": "ad22b4909e3e497b25b7620f427be134"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "0d9a43ba2952622fcece20042046ee72"
  }, {
    "url": "manifest.webmanifest",
    "revision": "51aa1d5274a2d7280615e226b76c7616"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
