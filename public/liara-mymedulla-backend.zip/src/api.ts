import axios from 'axios';

// ایجاد یک نمونه (instance) از اکسیوس با آدرس نسبی به سرور جاری
const api = axios.create({
  baseURL: '', // آدرس نسبی برای هماهنگی با سرور داخلی در هر دو محیط
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
  }
});

// ارسال خودکار توکن امنیتی در هدر همه درخواست‌ها
api.interceptors.request.use(
  (config) => {
    try {
      const token = localStorage.getItem('mentora_token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    } catch (_) {}
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// مدیریت خطای انقضا، نامعتبر بودن توکن و وضعیت آفلاین
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // خطای احراز هویت (۴۰۱)
    if (error?.response?.status === 401) {
      try {
        localStorage.removeItem('mentora_token');
        window.dispatchEvent(new Event('mentora_auth_change'));
      } catch (_) {}
    }

    // کنترل خطای شبکه / حالت آفلاین
    if (error?.code === 'ERR_NETWORK' || error?.message === 'Network Error' || !error?.response) {
      // این خطا در حالت آفلاین عادی است و به موتور صف آفلاین واگذار می‌شود
      console.warn('[Offline Mode / Network Handled]:', error.message || 'Offline');
    }

    return Promise.reject(error);
  }
);

export default api;
